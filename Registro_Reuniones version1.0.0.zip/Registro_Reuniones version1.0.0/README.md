# Registro_Reuniones
una aplicacion de escritorio que registra reuniones en una base de datos, puedes modificar, eliminar y guardar

agrega las sigientes lineas al archivo "Pom.xml" para agregar la dependencia a my SQL

<dependencies>
        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
            <version>8.0.24</version>
        </dependency>
    </dependencies>

