/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tablas;

/**
 *
 * @author Axcell Espinal
 */
public class Reunions {
    
    private String Nombre;
    private String Fecha;
    private String HoraI;
    private String HoraF;
    private String Lugar;
    private String Detalles;

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String Fecha) {
        this.Fecha = Fecha;
    }

    public String getHoraI() {
        return HoraI;
    }

    public void setHoraI(String HoraI) {
        this.HoraI = HoraI;
    }

    public String getHoraF() {
        return HoraF;
    }

    public void setHoraF(String HoraF) {
        this.HoraF = HoraF;
    }

    public String getLugar() {
        return Lugar;
    }

    public void setLugar(String Lugar) {
        this.Lugar = Lugar;
    }

    public String getDetalles() {
        return Detalles;
    }

    public void setDetalles(String Detalles) {
        this.Detalles = Detalles;
    }
}
